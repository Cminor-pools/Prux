Sample configuration files for:

SystemD: pruxd.service
Upstart: pruxd.conf
OpenRC:  pruxd.openrc
         pruxd.openrcconf
CentOS:  pruxd.init
OS X:    org.prux.pruxd.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
